package com.example.appdevproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class feedback extends AppCompatActivity{

    ImageView i1,i2,i3,i4,i5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);
        i1 = findViewById(R.id.star1);
        i2 = findViewById(R.id.star2);
        i3 = findViewById(R.id.star3);
        i4 = findViewById(R.id.star4);
        i5 = findViewById(R.id.star5);
        i1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                i1.setImageResource(R.drawable.ic_baseline_star_24);
                i2.setImageResource(R.drawable.ic_baseline_star_outline_24);
                i3.setImageResource(R.drawable.ic_baseline_star_outline_24);
                i4.setImageResource(R.drawable.ic_baseline_star_outline_24);
                i5.setImageResource(R.drawable.ic_baseline_star_outline_24);
            }
        });
        i2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                i1.setImageResource(R.drawable.ic_baseline_star_24);
                i2.setImageResource(R.drawable.ic_baseline_star_24);
                i3.setImageResource(R.drawable.ic_baseline_star_outline_24);
                i4.setImageResource(R.drawable.ic_baseline_star_outline_24);
                i5.setImageResource(R.drawable.ic_baseline_star_outline_24);
            }
        });
        i3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                i1.setImageResource(R.drawable.ic_baseline_star_24);
                i2.setImageResource(R.drawable.ic_baseline_star_24);
                i3.setImageResource(R.drawable.ic_baseline_star_24);
                i4.setImageResource(R.drawable.ic_baseline_star_outline_24);
                i5.setImageResource(R.drawable.ic_baseline_star_outline_24);
            }
        });
        i4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                i1.setImageResource(R.drawable.ic_baseline_star_24);
                i2.setImageResource(R.drawable.ic_baseline_star_24);
                i3.setImageResource(R.drawable.ic_baseline_star_24);
                i4.setImageResource(R.drawable.ic_baseline_star_24);
                i5.setImageResource(R.drawable.ic_baseline_star_outline_24);
            }
        });
        i5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                i1.setImageResource(R.drawable.ic_baseline_star_24);
                i2.setImageResource(R.drawable.ic_baseline_star_24);
                i3.setImageResource(R.drawable.ic_baseline_star_24);
                i4.setImageResource(R.drawable.ic_baseline_star_24);
                i5.setImageResource(R.drawable.ic_baseline_star_24);
            }
        });
    }
}