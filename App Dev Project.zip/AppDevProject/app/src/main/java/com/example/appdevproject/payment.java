package com.example.appdevproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class payment extends AppCompatActivity {

    TextView dateV,crimeV,copV,amountV;
    Button pay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);
        dateV = findViewById(R.id.date);
        crimeV = findViewById(R.id.crime);
        copV = findViewById(R.id.cop_name);
        amountV = findViewById(R.id.fine_amt);
        pay = findViewById(R.id.pay);
        String date = "30-08-2021";
        String crime = "Riding without helmet";
        String police = "Babu";
        String amount = "100";
        dateV.setText(date);
        crimeV.setText(crime);
        copV.setText(police);
        amountV.setText(amount);
    }
}