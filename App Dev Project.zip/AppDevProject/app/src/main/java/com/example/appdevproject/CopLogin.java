package com.example.appdevproject;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CopLogin extends AppCompatActivity {

    Button login;
    CheckBox check;
    EditText password,userName;
    TextView error;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cop_login);
        check = findViewById(R.id.showPassword);
        password = findViewById(R.id.password);
        userName = findViewById(R.id.username);
        error = findViewById(R.id.error);
        check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (check.isChecked()){
                    password.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }
                else{
                    password.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
            }
        });
        login = findViewById(R.id.login);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean flag = true;
                String message = "";
                if (!userName.getText().toString().equals("Police")){
                    message = message.concat("* Invalid UserName\n");
                    flag = false;
                }
                if (!password.getText().toString().equals("police")){
                    message = message.concat("* Invalid Password\n");
                    flag = false;
                }
                error.setText(message);
                if (flag){
                    Toast.makeText(CopLogin.this, "Success", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(getApplicationContext(),monitoring_content.class);
                    startActivity(intent);
                }
            }
        });
    }
}