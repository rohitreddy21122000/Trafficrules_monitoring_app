package com.example.appdevproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class civil_login extends AppCompatActivity {

    Button login, sendotp;
    EditText number,getotp;
    TextView error;
    int otp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_civil_login);
        getotp = findViewById(R.id.otpenter);
        number = findViewById(R.id.number);
        error = findViewById(R.id.error);
        login = findViewById(R.id.login);
        sendotp = findViewById(R.id.otpsend);
        sendotp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                otp = (int)(Math.random()*10000);
                Toast.makeText(civil_login.this, "Your OTP is " + Integer.toString(otp), Toast.LENGTH_SHORT).show();
            }
        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean flag = true;
                String message = "";
                if (number.getText().length() != 10){
                    message = message.concat("* Mobile Number should be 10 digits\n");
                    flag = false;
                }
                if (Integer.parseInt(getotp.getText().toString()) != otp){
                    message = message.concat("* Invalid OTP\n");
                    flag = false;
                }
                error.setText(message);
                if (flag){
                    Toast.makeText(civil_login.this, "Success", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(getApplicationContext(),civilian_home_page.class);
                    startActivity(intent);
                }
            }
        });
    }
}