package com.example.appdevproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class history extends AppCompatActivity {

    TextView dateV,crimeV,copV,amountV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        dateV = findViewById(R.id.date);
        crimeV = findViewById(R.id.crime);
        copV = findViewById(R.id.cop_name);
        amountV = findViewById(R.id.fine_amt);
        String date = "31-08-2021";
        String crime = "Riding without helmet";
        String police = "Babu";
        String amount = "100";
        dateV.setText(date);
        crimeV.setText(crime);
        copV.setText(police);
        amountV.setText(amount);
    }
}